<?php

namespace VLT\Toolkit\Modules\Integrations\Elementor\Extensions;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Core\Base\Module;
use Elementor\Controls_Manager;
use Elementor\Element_Base;
use Elementor\Plugin;

/**
 * Parallax Extension
 *
 * Handles GSAP ScrollTrigger parallax effects
 */
class ParallaxExtension extends Module {

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->add_actions();
	}

	/**
	 * Get module name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'parallax';
	}

	/**
	 * Register module scripts
	 */
	public function enqueue_frontend_scripts() {
		wp_enqueue_script( 'gsap' );
		wp_enqueue_script( 'scrolltrigger' );
	}

	/**
	 * Register Parallax controls
	 *
	 * @param Element_Base $element elementor element
	 */
	public function register_controls( $element ) {
		$element->add_control(
			'parallax_enable',
			[
				'label'              => esc_html__( 'Parallax', 'toolkit' ),
				'type'               => Controls_Manager::SWITCHER,
				'return_value'       => 'yes',
				'separator'          => 'before',
				'frontend_available' => true,
				'conditions' => [
					'relation' => 'or',
					'terms' => [
						[
							'terms' => [
								[
									'name' => 'background_background',
									'value' => 'classic',
								],
								[
									'name' => 'background_image[url]',
									'operator' => '!==',
									'value' => '',
								],
							],
						],
						[
							'terms' => [
								[
									'name' => 'background_background',
									'value' => 'gradient',
								],
								[
									'name' => 'background_color',
									'operator' => '!==',
									'value' => '',
								],
								[
									'name' => 'background_color_b',
									'operator' => '!==',
									'value' => '',
								],
							],
						],
					],
				],
			]
		);

		$element->add_control(
			'parallax_start',
			[
				'label'              => esc_html__( 'Start Position', 'toolkit' ),
				'type'               => Controls_Manager::TEXT,
				'default'            => 'top bottom',
				'placeholder'        => 'top bottom',
				'description'        => esc_html__( 'ScrollTrigger start position (e.g., "top bottom", "top center")', 'toolkit' ),
				'condition'          => [ 'parallax_enable' => 'yes' ],
				'frontend_available' => true,
			]
		);

		$element->add_control(
			'parallax_end',
			[
				'label'              => esc_html__( 'End Position', 'toolkit' ),
				'type'               => Controls_Manager::TEXT,
				'default'            => 'bottom top',
				'placeholder'        => 'bottom top',
				'description'        => esc_html__( 'ScrollTrigger end position (e.g., "bottom top", "bottom center")', 'toolkit' ),
				'condition'          => [ 'parallax_enable' => 'yes' ],
				'frontend_available' => true,
			]
		);

		$element->add_control(
			'parallax_scrub',
			[
				'label'              => esc_html__( 'Scrub', 'toolkit' ),
				'type'               => Controls_Manager::SWITCHER,
				'return_value'       => 'yes',
				'default'            => 'yes',
				'description'        => esc_html__( 'Smooth scrubbing effect', 'toolkit' ),
				'condition'          => [ 'parallax_enable' => 'yes' ],
				'frontend_available' => true,
			]
		);

		$element->add_control(
			'parallax_disable_mobile',
			[
				'label'              => esc_html__( 'Disable on Mobile', 'toolkit' ),
				'type'               => Controls_Manager::SWITCHER,
				'return_value'       => 'yes',
				'default'            => 'yes',
				'condition'          => [ 'parallax_enable' => 'yes' ],
				'frontend_available' => true,
			]
		);
	}

	/**
	 * Register WordPress hooks
	 */
	protected function add_actions() {
		// Register scripts
		add_action( 'elementor/frontend/after_enqueue_scripts', [ $this, 'enqueue_frontend_scripts' ] );

		// Register controls for containers (background section)
		add_action( 'elementor/element/container/section_background/before_section_end', [ $this, 'register_controls' ] );
	}
}
