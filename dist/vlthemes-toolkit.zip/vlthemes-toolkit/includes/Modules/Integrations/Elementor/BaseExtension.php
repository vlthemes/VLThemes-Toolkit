<?php

namespace VLT\Toolkit\Modules\Integrations\Elementor;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Base class for Elementor extensions
 *
 * Provides common functionality for all Elementor element extensions
 */
abstract class BaseExtension {
	/**
	 * Extension name
	 *
	 * @var string
	 */
	protected $name = '';

	/**
	 * Assets URL
	 *
	 * @var string
	 */
	protected $assets_url;

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->assets_url = VLT_TOOLKIT_URL . 'assets/';
		$this->init();
		$this->register_hooks();

		// Register scripts on proper WordPress hook.
		add_action( 'wp_enqueue_scripts', [ $this, 'register_scripts' ], 10 );

		// Register scripts for Elementor editor.
		add_action( 'elementor/editor/before_enqueue_scripts', [ $this, 'register_scripts' ], 10 );
	}

	/**
	 * Register extension scripts
	 *
	 * Override this method in child classes to register extension-specific scripts
	 */
	public function register_scripts() {
		// Can be overridden in child classes
	}

	/**
	 * Register extension controls
	 *
	 * @param object $element elementor element instance
	 * @param array  $args    element arguments
	 */
	abstract public function register_controls( $element, $args );

	/**
	 * Render extension attributes
	 *
	 * @param object $element elementor element instance
	 */
	abstract public function render_attributes( $element );

	/**
	 * Initialize extension
	 */
	abstract protected function init();

	/**
	 * Register WordPress hooks
	 */
	abstract protected function register_hooks();

	/**
	 * Get Elementor breakpoints
	 *
	 * @return array available breakpoints
	 */
	protected function get_elementor_breakpoints() {
		$breakpoints_manager = \Elementor\Plugin::$instance->breakpoints;
		$breakpoints         = $breakpoints_manager->get_active_breakpoints();

		$options = [];
		foreach ( $breakpoints as $breakpoint_key => $breakpoint ) {
			$options[ $breakpoint_key ] = $breakpoint->get_label();
		}

		return $options;
	}

	/**
	 * Get default reset devices (mobile and mobile_extra if exists)
	 *
	 * @return array
	 */
	protected function get_default_reset_devices() {
		$breakpoints = $this->get_elementor_breakpoints();

		$default_reset_devices = [ 'mobile' ];

		if ( isset( $breakpoints['mobile_extra'] ) ) {
			$default_reset_devices[] = 'mobile_extra';
		}

		return $default_reset_devices;
	}
}
