<?php

/**
 * Dashboard Demo Import Template
 */
if ( !defined( 'ABSPATH' ) ) {
	exit;
}

// Redirect to OCDI page
wp_safe_redirect( admin_url( 'themes.php?page=one-click-demo-import' ) );

exit;
