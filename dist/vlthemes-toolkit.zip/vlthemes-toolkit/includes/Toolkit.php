<?php

namespace VLT\Toolkit;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Main Toolkit class
 */
class Toolkit {
	/**
	 * Instance
	 *
	 * @var Toolkit
	 */
	private static $instance = null;

	/**
	 * Modules
	 *
	 * @var array
	 */
	private $modules = [];

	/**
	 * Plugin assets directory URL
	 *
	 * @var string
	 */
	private $plugin_assets_dir;

	/**
	 * Constructor
	 */
	private function __construct() {
		$this->load_base_module();
		$this->init_modules();
		$this->init_hooks();
	}

	/**
	 * Get instance
	 *
	 * @return Toolkit
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Enqueue admin scripts and styles
	 */
	public function enqueue_admin_scripts() {
		wp_enqueue_script(
			'vlt-entire-admin',
			$this->plugin_assets_dir . 'js/entire-admin.js',
			[],
			VLT_TOOLKIT_VERSION,
			true,
		);
	}

	/**
	 * Enqueue elementor editor admin scripts
	 */
	public function elementor_affiliate_script() {
		wp_enqueue_script(
			'vlt-elementor-editor-admin',
			$this->plugin_assets_dir . 'js/elementor-editor-admin.js',
			[],
			VLT_TOOLKIT_VERSION,
			true,
		);
	}

	/**
	 * Register all helper assets
	 *
	 * Registers scripts and styles but doesn't enqueue them
	 * Other modules can enqueue these as dependencies
	 */
	public function register_assets() {
		// Allow themes/plugins to register additional assets
		do_action( 'vlt_toolkit/register_assets' );
	}

	/**
	 * Get module
	 *
	 * @param string $module module name
	 *
	 * @return object|null
	 */
	public function get_module( $module ) {
		return isset( $this->modules[ $module ] ) ? $this->modules[ $module ] : null;
	}

	/**
	 * Minify CSS code
	 *
	 * Removes unnecessary whitespace, comments, and formatting from CSS
	 * to reduce file size and improve loading performance.
	 *
	 * @param string $css CSS code to minify
	 *
	 * @return string minified CSS code
	 */
	public static function minify_css( $css ) {
		// Reduce multiple spaces to single space
		$css = preg_replace( '/\s+/', ' ', $css );

		// Remove comments (except /*! important comments)
		$css = preg_replace( '/\/\*[^\!](.*?)\*\//s', '', $css );

		// Remove spaces around CSS syntax characters
		$css = preg_replace( '/\s?([\{\};,])\s?/', '$1', $css );

		// Clean up trailing semicolons and spaces after closing braces
		$css = str_replace( [ ';}', '} ' ], '}', $css );

		return trim( $css );
	}

	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		$this->plugin_assets_dir = VLT_TOOLKIT_URL . 'assets/';

		// Load text domain on init
		add_action( 'init', [ $this, 'load_textdomain' ] );

		// Enqueue admin scripts
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_scripts' ] );
		add_action( 'customize_controls_enqueue_scripts', [ $this, 'enqueue_admin_scripts' ] );

		// Elementor affiliate links
		add_action( 'admin_footer', [ $this, 'elementor_affiliate_script' ] );
		add_action( 'elementor/editor/footer', [ $this, 'elementor_affiliate_script' ] );

		// Register all helper assets (don't enqueue yet)
		add_action( 'wp_enqueue_scripts', [ $this, 'register_assets' ], 1 );
	}

	/**
	 * Load plugin text domain
	 */
	public function load_textdomain() {
		load_plugin_textdomain(
			'toolkit',
			false,
			dirname( plugin_basename( VLT_TOOLKIT_FILE ) ) . '/languages/'
		);
	}

	/**
	 * Load base module class
	 */
	private function load_base_module() {
		require_once VLT_TOOLKIT_PATH . 'includes/Modules/BaseModule.php';
	}

	/**
	 * Initialize modules
	 */
	private function init_modules() {
		$modules = [
			// Core feature modules
			'Features\\UploadMimes',
			'Features\\Widgets',
			'Features\\CustomFonts',
			'Features\\DemoImport',
			'Features\\SocialIcons',
			'Features\\TemplateParts',
			'Features\\PostViews',
			'Features\\AOS',
			'Features\\Breadcrumbs',
			'Features\\DynamicContent',
			// Helper modules
			'Helpers\\ImageHelper',
			'Helpers\\ContentHelper',
			'Helpers\\MediaHelper',
			// Integrations
			'Integrations\\Elementor',
			'Integrations\\ContactForm7',
			'Integrations\\VisualPortfolio',
			'Integrations\\WooCommerce',
			'Integrations\\ACF',
		];

		foreach ( $modules as $module ) {
			$this->load_module( $module );
		}

		do_action( 'vlt_toolkit/modules_loaded' );
	}

	/**
	 * Load module
	 *
	 * @param string $module module class name
	 */
	private function load_module( $module ) {
		$class_name = 'VLT\\Toolkit\\Modules\\' . $module;
		$file_path  = VLT_TOOLKIT_PATH . 'includes/Modules/' . str_replace( '\\', '/', $module ) . '.php';

		if ( file_exists( $file_path ) ) {
			require_once $file_path;

			if ( class_exists( $class_name ) ) {
				$this->modules[ $module ] = $class_name::instance();
			}
		}
	}
}
