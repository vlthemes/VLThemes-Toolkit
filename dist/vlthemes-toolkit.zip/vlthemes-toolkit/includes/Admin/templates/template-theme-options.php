<?php

/**
 * Dashboard Theme Options Template
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Redirect to Customizer
wp_safe_redirect( admin_url( 'customize.php' ) );

exit;
