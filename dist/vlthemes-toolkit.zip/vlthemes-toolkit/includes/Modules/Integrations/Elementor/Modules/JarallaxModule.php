<?php

namespace VLT\Toolkit\Modules\Integrations\Elementor\Module;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Stack;
use Elementor\Controls_Manager;
use Elementor\Element_Base;
use Elementor\Core\Base\Module as Module_Base;

/**
 * Parallax Extension
 *
 * Adds parallax effects to Elementor elements using Rellax.js
 */
class JarallaxModule extends Module_Base {

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->add_actions();
	}

	/**
	 * Get module name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'jarallax';
	}

	/**
	 * Register extension scripts
	 */
	public function register_scripts() {
		// wp_enqueue_script( 'rellax', VLT_TOOLKIT_URL . 'assets/vendors/js/rellax.js', [ 'jquery' ], VLT_TOOLKIT_VERSION, true );

		// wp_enqueue_style(
		// 	'vlt-parallax-background-module',
		// 	plugin_dir_url( __FILE__ ) . 'css/JarallaxModule.css',
		// 	[],
		// 	VLT_TOOLKIT_VERSION
		// );

		// wp_enqueue_script(
		// 	'vlt-parallax-background-module',
		// 	plugin_dir_url( __FILE__ ) . 'js/JarallaxModule.js',
		// 	[ 'jquery', 'elementor-frontend', 'rellax' ],
		// 	VLT_TOOLKIT_VERSION,
		// 	true
		// );

		wp_enqueue_style( 'jarallax' );

		wp_enqueue_script(
			'vlt-jarallax-module',
			plugin_dir_url( __FILE__ ) . 'js/JarallaxModule.js',
			[ 'jarallax', 'jarallax-video' ],
			VLT_TOOLKIT_VERSION,
			true,
		);




	}

	/**
	 * Register Parallax controls
	 *
	 * @param Element_Base $element Elementor element instance
	 */
	public function register_controls( Element_Base $element ) {

		$element->add_control(
			'vlt_jarallax_enabled',
			[
				'label' => esc_html__( 'Parallax Scrolling', 'toolkit' ),
				'type' => Controls_Manager::SWITCHER,
				'label_off' => esc_html__( 'Off', 'toolkit' ),
				'label_on' => esc_html__( 'On', 'toolkit' ),
				'render_type' => 'ui',
				'frontend_available' => true,
				'separator' => 'before',
				'conditions' => [
					'relation' => 'or',
					'terms' => [
						[
							'terms' => [
								[
									'name' => 'background_background',
									'value' => 'classic',
								],
								[
									'name' => 'background_image[url]',
									'operator' => '!==',
									'value' => '',
								],
							],
						],
						[
							'terms' => [
								[
									'name' => 'background_background',
									'value' => 'gradient',
								],
								[
									'name' => 'background_color',
									'operator' => '!==',
									'value' => '',
								],
								[
									'name' => 'background_color_b',
									'operator' => '!==',
									'value' => '',
								],
							],
						],
					],
				],
			],
		);

		$element->add_control(
			'vlt_jarallax_image',
			[
				'label'     => esc_html__( 'Background Image', 'toolkit' ),
				'type'      => Controls_Manager::MEDIA,
				'default'   => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
				'condition' => [ 'vlt_jarallax_enabled' => 'yes' ],
			],
		);

		$element->add_group_control(
			\Elementor\Group_Control_Image_Size::get_type(),
			[
				'name'      => 'vlt_jarallax_image',
				'default'   => 'full',
				'condition' => [ 'vlt_jarallax_enabled' => 'yes' ],
			]
		);

		$element->add_control(
			'vlt_jarallax_speed',
			[
				'label'      => esc_html__( 'Speed', 'toolkit' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => -1,
						'max'  => 2,
						'step' => 0.1,
					],
				],
				'default' => [
					'size' => 0.9,
				],
				'condition' => [ 'vlt_jarallax_enabled' => 'yes' ],
			],
		);

		$element->add_control(
			'vlt_jarallax_type',
			[
				'label'   => esc_html__( 'Type', 'toolkit' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					''               => esc_html__( 'Scroll', 'toolkit' ),
					'scale'          => esc_html__( 'Scale', 'toolkit' ),
					'opacity'        => esc_html__( 'Opacity', 'toolkit' ),
					'scroll-opacity' => esc_html__( 'Scroll + Opacity', 'toolkit' ),
					'scale-opacity'  => esc_html__( 'Scale + Opacity', 'toolkit' ),
				],
				'condition' => [ 'vlt_jarallax_enabled' => 'yes' ],
			],
		);

		$element->add_control(
			'vlt_jarallax_video_url',
			[
				'label'       => esc_html__( 'Video URL', 'toolkit' ),
				'description' => esc_html__( 'YouTube, Vimeo or local video. Use "mp4:" prefix for self-hosted.', 'toolkit' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => 'https://www.youtube.com/watch?v=...',
				'condition'   => [ 'vlt_jarallax_enabled' => 'yes' ],
			],
		);

	}

	/**
	 * Render Jarallax attributes
	 *
	 * @param object $widget elementor widget instance
	 */
	public function render_attributes( $widget ) {
		$settings = $widget->get_settings_for_display();

		if ( empty( $settings['vlt_jarallax_enabled'] ) || 'yes' !== $settings['vlt_jarallax_enabled'] ) {
			return;
		}

		$widget->add_render_attribute( '_wrapper', 'class', 'jarallax' );

		// Add jarallax class and speed
		if ( !empty( $settings['vlt_jarallax_speed']['size'] ) ) {
			$widget->add_render_attribute( '_wrapper', 'data-jarallax', '' );
			$widget->add_render_attribute( '_wrapper', 'data-speed', $settings['vlt_jarallax_speed']['size'] );
		}

		// Add video URL
		if ( !empty( $settings['vlt_jarallax_video_url'] ) ) {
			$widget->add_render_attribute( '_wrapper', 'data-jarallax-video', $settings['vlt_jarallax_video_url'] );
		}

		// Add type
		if ( !empty( $settings['vlt_jarallax_type'] ) ) {
			$widget->add_render_attribute( '_wrapper', 'data-type', $settings['vlt_jarallax_type'] );
		}
	}

	/**
	 * Register WordPress hooks
	 */
	protected function add_actions() {
		// Register controls for containers
		add_action( 'elementor/element/container/section_background/before_section_end', [ $this, 'register_controls' ] );

		// Render for containers
		add_action( 'elementor/frontend/container/before_render', [ $this, 'render_attributes' ] );

		// Enqueue scripts on frontend and editor
		add_action( 'elementor/frontend/after_enqueue_scripts', [ $this, 'register_scripts' ] );
	}
}
