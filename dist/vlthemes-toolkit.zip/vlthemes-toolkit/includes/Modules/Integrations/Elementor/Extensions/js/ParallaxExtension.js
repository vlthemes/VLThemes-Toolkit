(function ($) {
	$(window).on('elementor/frontend/init', () => {

		/**
		 * VLT Parallax Extension Handler
		 *
		 * Handles GSAP ScrollTrigger parallax effects for Elementor containers
		 */
		class VLTParallaxHandler extends elementorModules.frontend.handlers.Base {

			getDefaultElements() {
				return {
					$container: this.$element
				};
			}

			/**
			 * Check if device is mobile
			 */
			isMobile() {
				return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
			}

			/**
			 * Get parallax options from element settings
			 */
			getParallaxOptions() {
				const settings = this.getElementSettings();
				const options = {};

				// Speed
				if (settings.parallax_speed && typeof settings.parallax_speed.size !== 'undefined') {
					options.speed = settings.parallax_speed.size;
				} else {
					options.speed = 50;
				}

				// Type
				options.type = settings.parallax_type || 'y';

				// Start/End positions
				options.start = settings.parallax_start || 'top bottom';
				options.end = settings.parallax_end || 'bottom top';

				// Scrub
				options.scrub = settings.parallax_scrub === 'yes' ? true : false;

				// Disable on mobile
				options.disableMobile = settings.parallax_disable_mobile === 'yes';

				return options;
			}

			/**
			 * Activate parallax
			 */
			activate() {
				// Check for GSAP and ScrollTrigger
				if (typeof gsap === 'undefined') {
					console.warn('GSAP library not loaded');
					return;
				}

				if (typeof ScrollTrigger === 'undefined') {
					console.warn('GSAP ScrollTrigger plugin not loaded');
					return;
				}

				const options = this.getParallaxOptions();

				// Skip if mobile and disabled
				if (options.disableMobile && this.isMobile()) {
					return;
				}

				const $el = this.elements.$container;
				const element = $el.get(0);

				// Build animation based on type
				let animationProps = {};

				switch (options.type) {
					case 'y':
						animationProps.y = options.speed;
						break;
					case 'x':
						animationProps.x = options.speed;
						break;
					case 'scale':
						const scaleValue = 1 + (options.speed / 100);
						animationProps.scale = scaleValue;
						break;
					case 'opacity':
						const opacityValue = Math.max(0, Math.min(1, 1 - (options.speed / 100)));
						animationProps.opacity = opacityValue;
						break;
					case 'rotate':
						animationProps.rotation = options.speed;
						break;
				}

				// Create ScrollTrigger animation
				this.scrollTriggerInstance = gsap.to(element, {
					...animationProps,
					ease: 'none',
					scrollTrigger: {
						trigger: element,
						start: options.start,
						end: options.end,
						scrub: options.scrub ? 1 : false,
						// markers: true, // Uncomment for debugging
					}
				});
			}

			/**
			 * Deactivate parallax
			 */
			deactivate() {
				if (this.scrollTriggerInstance) {
					// Kill the ScrollTrigger and animation
					this.scrollTriggerInstance.scrollTrigger?.kill();
					this.scrollTriggerInstance.kill();
					this.scrollTriggerInstance = null;
				}

				// Reset element styles
				const $el = this.elements.$container;
				const element = $el.get(0);

				gsap.set(element, {
					clearProps: 'all'
				});
			}

			/**
			 * Toggle parallax based on settings
			 */
			toggle() {
				const settings = this.getElementSettings();

				if (settings.parallax_enable === 'yes') {
					this.activate();
				} else {
					this.deactivate();
				}
			}

			/**
			 * Initialize handler
			 */
			onInit() {
				super.onInit();

				// Wait for GSAP and ScrollTrigger to be ready
				if (typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined') {
					this.toggle();
				} else {
					// Retry after a short delay
					setTimeout(() => this.toggle(), 100);
				}
			}

			/**
			 * Handle element changes in editor
			 */
			onElementChange(propertyName) {
				if (propertyName.indexOf('parallax') === 0) {
					// Deactivate first, then toggle
					this.deactivate();

					// Small delay to ensure cleanup is complete
					setTimeout(() => {
						this.toggle();
					}, 50);
				}
			}

			/**
			 * Cleanup on destroy
			 */
			onDestroy() {
				this.deactivate();
			}
		}

		// Register handlers when Elementor frontend is ready
		$(window).on('elementor/frontend/init', () => {
			// Handle containers
			elementorFrontend.hooks.addAction('frontend/element_ready/container', ($element) => {
				elementorFrontend.elementsHandler.addHandler(VLTParallaxHandler, { $element });
			});
		});
	});
})(jQuery);

