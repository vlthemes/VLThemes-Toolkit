/**
 * VLT Elementor Main Entry Point
 *
 * Initializes and coordinates all Elementor extension modules
 */

import { isMobileDevice, debounceResize, initResizeHandlers } from './core/utils.js';
import AOSModule from './modules/aos.js';
import JarallaxModule from './modules/jarallax.js';
import ElementParallaxModule from './modules/element-parallax.js';
import ContainerExtensionsModule from './modules/container-extensions.js';


(function () {
	'use strict';

	// ===================================
	// INITIALIZATION
	// ===================================

	// Initialize resize handlers
	initResizeHandlers();

	// ===================================
	// MODULES
	// ===================================

	// Initialize modules with shared utilities
	const aosModule = new AOSModule({ isMobileDevice, debounceResize });
	const jarallaxModule = new JarallaxModule({ isMobileDevice, debounceResize });
	const elementParallaxModule = new ElementParallaxModule({ isMobileDevice, debounceResize });
	const containerExtensionsModule = new ContainerExtensionsModule({ debounceResize });

	// ===================================
	// SITE LOADED
	// ===================================

	/**
	 * Site loaded event
	 * Fires when all content is loaded and ready
	 */
	function onSiteLoaded() {
		// Initialize AOS
		aosModule.init();
		aosModule.setupRefreshHandlers();

		// Initialize Jarallax
		jarallaxModule.init();
		jarallaxModule.setupRefreshHandlers();

		// Initialize Element Parallax
		elementParallaxModule.init();
		elementParallaxModule.setupRefreshHandlers();

		// Initialize Container Extensions
		containerExtensionsModule.init();
		containerExtensionsModule.setupRefreshHandlers();

		// Dispatch custom event
		document.dispatchEvent(new CustomEvent('vlt.site-loaded'));

		console.info('VLT Helper initialized');
	}

	// Initialize when DOM is ready
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', onSiteLoaded);
	} else {
		// DOM already loaded
		onSiteLoaded();
	}

})();
