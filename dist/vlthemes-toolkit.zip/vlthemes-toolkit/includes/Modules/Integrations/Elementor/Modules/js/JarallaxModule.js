(function () {
	'use strict';

	if (typeof Rellax === 'undefined') {
		console.warn('Rellax.js not loaded — VLT Parallax Background disabled');
		return;
	}

	class ParallaxBackgroundHandler extends elementorModules.frontend.handlers.Base {

		getDefaultSettings() {
			return {
				addBackgroundLayerTo: '',
				classes             : {
					element  : 'elementor-motion-parallax',
					wrapper: 'elementor-motion-effects-container',
					layer    : 'elementor-motion-effects-layer',
				}
			};
		}

		createParallaxLayers() {
			const settings = this.getSettings();

			this.elements.$parallaxWrapper = jQuery('<div>', { class: settings.classes.wrapper });
			this.elements.$parallaxLayer   = jQuery('<div>', { class: settings.classes.layer });

			this.elements.$parallaxWrapper.prepend(this.elements.$parallaxLayer);

			const $targetElement = settings.addBackgroundLayerTo
				? this.$element.find(settings.addBackgroundLayerTo)
				:   this.$element;

			$targetElement.prepend(this.elements.$parallaxWrapper);
		}

		removeParallaxLayers() {
			if (this.elements.$parallaxWrapper) {
				this.elements.$parallaxWrapper.remove();
			}
		}

		getParallaxSpeed() {
			const  speedSetting                        = this.getElementSettings('vlt_rellax_background_speed');
			return speedSetting && speedSetting.size !== undefined
				? parseFloat(speedSetting.size)
				:   0.5;
		}

		enableParallax() {
			this.createParallaxLayers();
			this.$element.addClass(this.getSettings('classes.element'));

			const speed = this.getParallaxSpeed();

			this.rellaxInstance = new Rellax(this.elements.$parallaxLayer.get(0), {
				speed : speed,
				center: true
			});
		}

		disableParallax() {
			this.$element.removeClass(this.getSettings('classes.element'));

			if (this.rellaxInstance) {
				this.rellaxInstance.destroy();
				this.rellaxInstance = null;
			}

			this.removeParallaxLayers();
		}

		updateParallaxState() {
			const isEnabled = this.getElementSettings('vlt_rellax_background_enable') === 'yes';

			if (isEnabled) {
				this.disableParallax();// clean up first
				this.enableParallax  ();// recreate with latest settings
			} else {
				this.disableParallax();
			}
		}

		onInit() {
			super.onInit();
			this.updateParallaxState();
		}

		onElementChange(propertyName) {
			if (
				propertyName === 'vlt_rellax_background_enable' ||
				propertyName === 'vlt_rellax_background_speed'
			) {
				this.updateParallaxState();
			}
		}
	}

	window.addEventListener('elementor/frontend/init', () => {
		elementorFrontend.hooks.addAction('frontend/element_ready/container', ($scope) => {
			elementorFrontend.elementsHandler.addHandler(ParallaxBackgroundHandler, {
				$element: $scope
			});
		});
	});

})();